# My Package

This package is designed for managing and visualizing neuroscience data.

## Installation

Install my_package using pip:

```bash
pip install kosi_dj_package
